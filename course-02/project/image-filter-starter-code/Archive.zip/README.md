# SJS: Udagram Image Filtering Microservice

Name: Steph Stammel
Screenshots: ./deployment_screenshots
Github repo: https://github.com/stephstammel/cloud-developer/tree/master/course-02/project/image-filter-starter-code
Endpoint URL: http://stammel-application.us-east-2.elasticbeanstalk.com/filteredimage
Example URL: ?image_url=https://timedotcom.files.wordpress.com/2019/03/kitten-report.jpg